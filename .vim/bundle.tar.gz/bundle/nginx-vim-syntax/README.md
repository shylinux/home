# nginx syntax files for Vim.

*NOTE*: As of Dec. 2013, these scripts are maintained in the "contrib" directory of the Nginx source:

* http://hg.nginx.org/nginx/rev/f38043bd15f5

You can see the original vim.org version here: 

* http://www.vim.org/scripts/script.php?script_id=1886

