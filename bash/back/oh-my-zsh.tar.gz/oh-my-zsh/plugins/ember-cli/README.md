# Ember CLI

**Maintainers:** [BilalBudhani](http://www.github.com/BilalBudhani), [eubenesa](http://www.github.com/eubenesa)

Ember CLI (http://www.ember-cli.com/)

### List of Aliases

Alias | Ember-CLI command
----- | -----------------
**es** | *ember serve*
**ea** | *ember addon*
**eb** | *ember build*
**ed** | *ember destroy*
**eg** | *ember generate*
**eh** | *ember help*
**ein** | *ember init*
**ei** | *ember install*
**et** | *ember test*
**eu** | *ember update*
**ev** | *ember version*
